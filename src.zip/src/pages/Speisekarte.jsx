
import { useContext } from "react";
import { AppContext } from "../App";

const products = [
      {
          "ID": 0,
          "product": "Cola",
          "bar": true,
          "kitchen": false,
          "price": 3.80
      },
      {
          "ID": 1,
          "product": "Fanta",
          "bar": true,
          "kitchen": false,
          "price": 3.80
      },
      {
          "ID": 3,
          "product": "Sprite",
          "bar": true,
          "kitchen": false,
          "price": 3.80
      },
      {
          "ID": 4,
          "product": "Mezzo",
          "bar": true,
          "kitchen": false,
          "price": 3.80
      },
      {
          "ID": 5,
          "product": "Wasser 0,5l",
          "bar": true,
          "kitchen": false,
          "price": 3.40
      },
      {
          "ID": 6,
          "product": "Adelholzener 0,7l",
          "bar": true,
          "kitchen": false,
          "price": 5.80
      },
      {
          "ID": 7,
          "product": "San Pellegrino 1,0l",
          "bar": true,
          "kitchen": false,
          "price": 6.80
      },
      {
          "ID": 8,
          "product": "Augustiner Helles",
          "bar": true,
          "kitchen": false,
          "price": 3.40
      },
      {
          "ID": 9,
          "product": "Montepulciano 0,2l",
          "bar": true,
          "kitchen": false,
          "price": 4.80
      },
      {
          "ID": 10,
          "product": "Chardonnay 0,2l",
          "bar": true,
          "kitchen": false,
          "price": 4.80
      },
      {
          "ID": 101,
          "product": "Cotoletta Milanese",
          "bar": false,
          "kitchen": true,
          "price": 15.50
      },
      {
          "ID": 102,
          "product": "Calamari fritti",
          "bar": false,
          "kitchen": true,
          "price": 15.00
      },
      {
          "ID": 103,
          "product": "Calamari ai ferri",
          "bar": false,
          "kitchen": true,
          "price": 17.50
      },
      {
          "ID": 110,
          "product": "Tiramisu",
          "bar": false,
          "kitchen": true,
          "price": 5.50
      },
      {
          "ID": 120,
          "product": "Pizza pane 30cm",
          "bar": false,
          "kitchen": true,
          "price": 8.50
      },
      {
          "ID": 121,
          "product": "Pizza pane speciale 30cm",
          "bar": false,
          "kitchen": true,
          "price": 10.80
      },
      {
          "ID": 122,
          "product": "Pizza Margherita 30cm",
          "bar": false,
          "kitchen": true,
          "price": 11.80
      },
      {
          "ID": 123,
          "product": "Pizza Funghi 30cm",
          "bar": false,
          "kitchen": true,
          "price": 12.30
      },
      {
          "ID": 124,
          "product": "Pizza della casa 30cm",
          "bar": false,
          "kitchen": true,
          "price": 14.50
      },
      {
          "ID": 125,
          "product": "Pizza Parma 30cm",
          "bar": false,
          "kitchen": true,
          "price": 15.50
      }
  ]

export const Speisekarte = () => {
    const { products } = useContext(AppContext);
    return <div className="Speisekarte">
      <h1>Speisekarte</h1>
      <h2>{products}</h2>
  
    </div>;
  };



   