import { useContext } from "react";
import { AppContext } from "../App";

export const Nachspeisen = () => {
  
  return <div className="Nachspeisen">
    <h1>Nachspeisen</h1>
    <h2>Tiramisu</h2>

  </div>;
};