import { useContext } from "react";
import { AppContext } from "../App";

export const Vorspeisen = () => {
  
  return <div className="Vorspeisen">
    <h1>Vorspeisen</h1>
    <h2>Suppe</h2>

  </div>;
};
