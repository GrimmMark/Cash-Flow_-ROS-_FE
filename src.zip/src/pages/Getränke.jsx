import { useContext } from "react";
import { AppContext } from "../App";

export const Getränke = () => {
  
  return <div className="Getränke">
    <h1>Getränke</h1>
    <h2></h2>
<button id="btn">Cola</button>
<button id="btn">Fanta</button>
<button id="btn">Sprite</button>
<button id="btn">MezzoMix</button>
<button id="btn">Tafelwasser</button>
<button id="btn">Pellegrino 0,2l</button>
<button id="btn">Pellegrino 1,0l</button>
<button id="btn">Helles</button>
<button id="btn">Weißbier</button>
<button id="btn">Radler</button>
<button id="btn">Montepulciono 0,2l</button>
<button id="btn">Chardonnay 0,2l</button>
<h2></h2>
  </div>;
};