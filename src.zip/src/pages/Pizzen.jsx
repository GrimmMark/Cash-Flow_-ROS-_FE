import { useContext } from "react";
import { AppContext } from "../App";

export const Pizzen = () => {
  
  return <div className="Pizzen">
    <h1>Pizzen</h1>
    <h2>Pizza Pane</h2>

  </div>;
};