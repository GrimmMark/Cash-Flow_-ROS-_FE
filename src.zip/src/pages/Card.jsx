import { useContext } from "react";
import { AppContext } from "../App";
import { Link } from "react-router-dom";

export const Card = () => {
  
  return <div className="Card">
    <h1>Speisekarte</h1>
    <h2></h2>
    <div className="Navbar">
    <Link className="nav" to="/Getränke"> Getränke </Link>
    <Link className="nav" to="/Vorspeisen"> Vorspeisen </Link>
    <Link className="nav" to="/Hauptspeisen"> Hauptspeisen </Link>
    <Link className="nav" to="/Pizzen"> Pizzen </Link>
    <Link className="nav" to="/Nachspeisen"> Nachspeisen </Link>
    </div>
    <h2></h2>
  </div>;
};