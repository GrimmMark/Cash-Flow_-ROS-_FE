import { useContext } from "react";
import { ChangeProfile } from "../ChangeProfile";
import { AppContext } from "../App";


export const Profile = () => {
  const { order } = useContext(AppContext);
  return (
    <div className="profileP">
      
      <div className="change">
        <ChangeProfile />
      </div>
      <h1>{order}</h1>
    </div>
  );
};