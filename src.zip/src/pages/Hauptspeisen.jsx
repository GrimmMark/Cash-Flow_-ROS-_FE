import { useContext } from "react";
import { AppContext } from "../App";

export const Hauptspeisen = () => {
  
  return <div className="Hauptspeisen">
    <h1>Hauptspeisen</h1>
    <h2>Schnitzel</h2>

  </div>;
};