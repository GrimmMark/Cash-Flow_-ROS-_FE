import { Link } from "react-router-dom"; // import link component

export const Tablelist = () => {
  return (
    <div className="Navbar">
      {/* using Link to adress the different pages like defined before in <Routes> */}
      <Link className="nav" to="/Tisch1"> Tisch1 </Link>
      <Link className="nav" to="/Tisch2"> Tisch2 </Link>
      <Link className="nav" to="/Tisch3"> Tisch3 </Link>
      <Link className="nav" to="/Tisch4"> Tisch4 </Link>
      <Link className="nav" to="/Tisch5"> Tisch5 </Link>
      <Link className="nav" to="/Tisch6"> Tisch6 </Link>
      <Link className="nav" to="/Tisch7"> Tisch7 </Link>
      <Link className="nav" to="/Tisch8"> Tisch8 </Link>
      <Link className="nav" to="/Tisch9"> Tisch9 </Link>
      <Link className="nav" to="/Tisch10"> Tisch10 </Link>
    
    </div>
  );
};
