import "./App.css";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// import pages to jump to
import { Bar } from "./displays/Bar";
import { Kitchen } from "./displays/Kitchen";
import { Orders } from "./displays/Orders";
import { Card } from "./pages/Card";

import { Getränke } from "./pages/Getränke";
import { Vorspeisen } from "./pages/Vorspeisen";
import { Hauptspeisen } from "./pages/Hauptspeisen";
import { Pizzen } from "./pages/Pizzen";
import { Nachspeisen } from "./pages/Nachspeisen";

import { Tisch1 } from "./tables/Tisch1";
import { Tisch2 } from "./tables/Tisch2";
import { Tisch3 } from "./tables/Tisch3";
import { Tisch4 } from "./tables/Tisch4";
import { Tisch5 } from "./tables/Tisch5";
import { Tisch6 } from "./tables/Tisch6";
import { Tisch7 } from "./tables/Tisch7";
import { Tisch8 } from "./tables/Tisch8";
import { Tisch9 } from "./tables/Tisch9";
import { Tisch10 } from "./tables/Tisch10";

import { Tablelist } from "./Tablelist";
import { DisplayList } from "./Displaylist";
import { useState, createContext } from "react";
import { Speisekarte } from "./pages/Speisekarte";
// need to install : npm install react-router-dom

export const AppContext = createContext();

function App() {
  
  const [order1, setOrder1] = useState('Order1');
  const [order2, setOrder2] = useState('Order2');
  const [order3, setOrder3] = useState('Order3');
  const [order4, setOrder4] = useState('Order3');
  const [order5, setOrder5] = useState('Order3');
  const [order6, setOrder6] = useState('Order3');
  const [order7, setOrder7] = useState('Order3');
  const [order8, setOrder8] = useState('Order3');
  const [order9, setOrder9] = useState('Order3');
  const [order10, setOrder10] = useState('Order3');

  return (
    <div className="App">
      {/* this is where the routes shall be in the code - Router */}
      <AppContext.Provider value={{ order1, setOrder1, order2, setOrder2, order3, setOrder3, order4, setOrder4, order5, setOrder5, order6, setOrder6, order7, setOrder7, order8, setOrder8, order9, setOrder9, order10, setOrder10 }}>
        <Router>
          {/* adding our component Navbar fixed on top */}
          <Tablelist />
          {/* here now the different pages incl. path to jump to and change screen below Navbar */}
          <Routes>
            <Route path="/Tisch1" id="relement" element={<Tisch1 />} />
            <Route path="/Tisch2" id="relement" element={<Tisch2 />} />
            <Route path="/Tisch3" id="relement" element={<Tisch3 />} />
            <Route path="/Tisch4" id="relement" element={<Tisch4 />} />
            <Route path="/Tisch5" id="relement" element={<Tisch5 />} />
            <Route path="/Tisch6" id="relement" element={<Tisch6 />} />
            <Route path="/Tisch7" id="relement" element={<Tisch7 />} />
            <Route path="/Tisch8" id="relement" element={<Tisch8 />} />
            <Route path="/Tisch9" id="relement" element={<Tisch9 />} />
            <Route path="/Tisch10" id="relement" element={<Tisch10 />} />
          
            <Route path="/Bar" id="relement" element={<Bar />} />
            <Route path="/Kitchen" id="relement" element={<Kitchen />} />
            <Route path="/Orders" id="relement" element={<Orders />} />
            <Route path="/Card" id="relement" element={<Card />} />

            <Route path="/Getränke" id="relement" element={<Getränke />} />
            <Route path="/Vorspeisen" id="relement" element={<Vorspeisen />} />
            <Route path="/Hauptspeisen" id="relement" element={<Hauptspeisen />} />
            <Route path="/Pizzen" id="relement" element={<Pizzen />} />
            <Route path="/Nachspeisen" id="relement" element={<Nachspeisen />} />
            {/* having a error page when no path found */}
            <Route path="*" element={<h1> PAGE NOT FOUND</h1>} />
          </Routes>
          
          <DisplayList />
          

          
        </Router>
      </AppContext.Provider>
    </div>
  );
}

export default App;
