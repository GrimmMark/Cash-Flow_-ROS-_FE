import { useState } from "react";
import { useContext } from "react";
import { AppContext } from "./App";

export const ChangeProfile = () => {

    const { setUserName } = useContext(AppContext);
    const [newUserName, setNewUserName] = useState("");
    return (
        <div className="changeP">
            <p>Change Profile</p>
            <input id="input" onChange={(event) => { setNewUserName(event.target.value); }} />
            <button id="btn" onClick={() => { setUserName(newUserName) }} > {" "} Change Username</button>
        </div>
    );
};