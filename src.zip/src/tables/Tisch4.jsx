import { useContext } from "react";
import { AppContext } from "../App";
import { Link } from "react-router-dom";

export const Tisch4 = () => {
  const { order4 } = useContext(AppContext);
  return <div className="Tisch">
    <h1>Tisch4</h1>
    <h2>{order4}</h2>
    <h2></h2>
    <div className="Navbar">
    <Link className="nav" to="/Getränke"> Getränke </Link>
    <Link className="nav" to="/Vorspeisen"> Vorspeisen </Link>
    <Link className="nav" to="/Hauptspeisen"> Hauptspeisen </Link>
    <Link className="nav" to="/Pizzen"> Pizzen </Link>
    <Link className="nav" to="/Nachspeisen"> Nachspeisen </Link>
    </div>
  </div>;
};