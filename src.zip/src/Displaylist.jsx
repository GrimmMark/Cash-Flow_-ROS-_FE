import { Link } from "react-router-dom"; // import link component

export const DisplayList = () => {
  return (
    <div className="Navbar">
      {/* using Link to adress the different pages like defined before in <Routes> */}
      <Link className="nav" to="/Bar"> Bar </Link>
      <Link className="nav" to="/Kitchen"> Küche </Link>
      <Link className="nav" to="/Orders"> Offene Bestellungen </Link>
      <Link className="nav" to="/Card"> Speisekarte </Link>

    </div>
  );
};