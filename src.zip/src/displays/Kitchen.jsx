import { useContext } from "react";
import { AppContext } from "../App";

export const Kitchen = () => {
  
  return <div className="kitchen">
    <h1>Küche</h1>
    <h2>orderK</h2>

  </div>;
};
