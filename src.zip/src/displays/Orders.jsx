import { useContext } from "react";
import { AppContext } from "../App";

export const Orders = () => {
  
  return <div className="orders">
    <h1>Offene Bestellungen</h1>
    <h2>all orders</h2>

  </div>;
};
