import { useContext } from "react";
import { AppContext } from "../App";

export const Bar = () => {
  
  return <div className="Bar">
    <h1>Bar</h1>
    <h2>orderB</h2>

  </div>;
};
